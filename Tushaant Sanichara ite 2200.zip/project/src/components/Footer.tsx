import React from 'react';
import { Shield, Mail, Phone, MapPin } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 border-t border-slate-800 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo and Description */}
          <div className="md:col-span-2">
            <div className="flex items-center space-x-3 mb-4">
              <Shield className="h-8 w-8 text-cyan-400" />
              <div>
                <h3 className="text-xl font-bold text-white">UGCC</h3>
                <p className="text-xs text-cyan-400">University of Guyana Cybersecurity Club</p>
              </div>
            </div>
            <p className="text-gray-300 mb-4 max-w-md">
              Empowering the next generation of cybersecurity professionals through education, 
              practical experience, and community engagement.
            </p>
            <p className="text-sm text-gray-400">
              "Securing Tomorrow, Today"
            </p>
          </div>

          {/* Contact Information */}
          <div>
            <h4 className="text-lg font-semibold text-white mb-4">Contact Us</h4>
            <div className="space-y-3">
              <div className="flex items-center gap-3 text-gray-300">
                <Mail className="h-4 w-4 text-cyan-400" />
                <a href="mailto:ugcc@uog.edu.gy" className="hover:text-cyan-400 transition-colors">
                  ugcc@uog.edu.gy
                </a>
              </div>
              <div className="flex items-center gap-3 text-gray-300">
                <Phone className="h-4 w-4 text-cyan-400" />
                <span>+592-222-4000 ext. 3456</span>
              </div>
              <div className="flex items-start gap-3 text-gray-300">
                <MapPin className="h-4 w-4 text-cyan-400 mt-0.5" />
                <span className="text-sm">
                  Computer Science Department<br />
                  University of Guyana<br />
                  Turkeyen Campus
                </span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold text-white mb-4">Quick Links</h4>
            <div className="space-y-2">
              <a href="#" className="block text-gray-300 hover:text-cyan-400 transition-colors">About UGCC</a>
              <a href="#" className="block text-gray-300 hover:text-cyan-400 transition-colors">Join Us</a>
              <a href="#" className="block text-gray-300 hover:text-cyan-400 transition-colors">Events</a>
              <a href="#" className="block text-gray-300 hover:text-cyan-400 transition-colors">Resources</a>
              <a href="#" className="block text-gray-300 hover:text-cyan-400 transition-colors">Constitution</a>
            </div>
          </div>
        </div>

        <div className="border-t border-slate-800 pt-8 mt-8 text-center">
          <p className="text-gray-400 text-sm">
            © 2025 University of Guyana Cybersecurity Club. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;