import React from 'react';
import { Calendar, Mail, Linkedin } from 'lucide-react';

const Executives: React.FC = () => {
  const currentExecutives = [
    {
      id: '1',
      name: 'Sarah Johnson',
      position: 'President',
      year: '2024-2025',
      bio: 'Final year Computer Science student specializing in network security and ethical hacking.',
      image_url: 'https://images.pexels.com/photos/3756679/pexels-photo-3756679.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
      email: 'sarah.johnson@uog.edu.gy',
      linkedin: 'linkedin.com/in/sarahjohnson'
    },
    {
      id: '2',
      name: 'Marcus Williams',
      position: 'Vice President',
      year: '2024-2025',
      bio: 'Third year IT student with expertise in digital forensics and incident response.',
      image_url: 'https://images.pexels.com/photos/3777931/pexels-photo-3777931.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
      email: 'marcus.williams@uog.edu.gy',
      linkedin: 'linkedin.com/in/marcuswilliams'
    },
    {
      id: '3',
      name: 'Priya Patel',
      position: 'Secretary',
      year: '2024-2025',
      bio: 'Second year CS student passionate about cryptography and secure communications.',
      image_url: 'https://images.pexels.com/photos/3756679/pexels-photo-3756679.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
      email: 'priya.patel@uog.edu.gy',
      linkedin: 'linkedin.com/in/priyapatel'
    },
    {
      id: '4',
      name: 'David Chen',
      position: 'Treasurer',
      year: '2024-2025',
      bio: 'Third year student focusing on cybersecurity policy and risk management.',
      image_url: 'https://images.pexels.com/photos/3777931/pexels-photo-3777931.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
      email: 'david.chen@uog.edu.gy',
      linkedin: 'linkedin.com/in/davidchen'
    }
  ];

  const pastExecutives = [
    {
      id: '5',
      name: 'Alexandra Rodriguez',
      position: 'President',
      year: '2023-2024',
      bio: 'Led the club through significant growth, organizing multiple successful CTF competitions.',
      achievements: ['Organized first inter-university CTF', 'Grew membership by 200%']
    },
    {
      id: '6',
      name: 'Michael Thompson',
      position: 'Vice President',
      year: '2023-2024',
      bio: 'Established partnerships with local cybersecurity firms and government agencies.',
      achievements: ['Secured industry partnerships', 'Launched mentorship program']
    }
  ];

  return (
    <div className="min-h-screen bg-slate-900 py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Current Executives */}
        <div className="mb-20">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-white mb-4">Current Executive Team</h1>
            <p className="text-xl text-gray-300 flex items-center justify-center gap-2">
              <Calendar className="h-5 w-5 text-cyan-400" />
              Academic Year 2024-2025
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {currentExecutives.map((exec) => (
              <div key={exec.id} className="bg-slate-800 rounded-xl border border-slate-700 overflow-hidden hover:border-cyan-400 transition-colors">
                <div className="aspect-w-1 aspect-h-1">
                  <img
                    src={exec.image_url}
                    alt={exec.name}
                    className="w-full h-64 object-cover"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-white mb-1">{exec.name}</h3>
                  <p className="text-cyan-400 font-semibold mb-3">{exec.position}</p>
                  <p className="text-gray-300 text-sm mb-4">{exec.bio}</p>
                  
                  <div className="space-y-2">
                    <a
                      href={`mailto:${exec.email}`}
                      className="flex items-center gap-2 text-sm text-gray-400 hover:text-cyan-400 transition-colors"
                    >
                      <Mail className="h-4 w-4" />
                      Contact
                    </a>
                    <a
                      href={`https://${exec.linkedin}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 text-sm text-gray-400 hover:text-cyan-400 transition-colors"
                    >
                      <Linkedin className="h-4 w-4" />
                      LinkedIn
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Past Executives */}
        <div>
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-white mb-4">Past Executive Leadership</h2>
            <p className="text-lg text-gray-300">Honoring those who built the foundation of UGCC</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {pastExecutives.map((exec) => (
              <div key={exec.id} className="bg-slate-800 p-8 rounded-xl border border-slate-700">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-xl font-bold text-white mb-1">{exec.name}</h3>
                    <p className="text-cyan-400 font-semibold">{exec.position}</p>
                    <p className="text-sm text-gray-400">{exec.year}</p>
                  </div>
                </div>
                
                <p className="text-gray-300 mb-4">{exec.bio}</p>
                
                {exec.achievements && (
                  <div>
                    <h4 className="text-sm font-semibold text-cyan-400 mb-2">Key Achievements:</h4>
                    <ul className="text-sm text-gray-300 space-y-1">
                      {exec.achievements.map((achievement, index) => (
                        <li key={index}>• {achievement}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Executives;