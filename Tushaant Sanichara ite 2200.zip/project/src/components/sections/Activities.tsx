import React from 'react';
import { Calendar, Clock, MapPin, Users, Trophy, BookOpen, Coffee } from 'lucide-react';

const Activities: React.FC = () => {
  const upcomingActivities = [
    {
      id: '1',
      title: 'Ethical Hacking Workshop',
      description: 'Learn the fundamentals of ethical hacking and penetration testing techniques.',
      date: '2025-02-15',
      time: '2:00 PM - 5:00 PM',
      location: 'Computer Lab 3, CS Department',
      type: 'workshop' as const,
      attendees: 25,
      image_url: 'https://images.pexels.com/photos/5380664/pexels-photo-5380664.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      id: '2',
      title: 'CTF Competition 2025',
      description: 'Annual Capture The Flag competition with prizes and recognition.',
      date: '2025-03-10',
      time: '9:00 AM - 6:00 PM',
      location: 'Main Auditorium',
      type: 'competition' as const,
      attendees: 150,
      image_url: 'https://images.pexels.com/photos/5380664/pexels-photo-5380664.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      id: '3',
      title: 'Cybersecurity Career Panel',
      description: 'Industry professionals share insights on cybersecurity career paths.',
      date: '2025-03-25',
      time: '6:00 PM - 8:00 PM',
      location: 'Lecture Theatre A',
      type: 'seminar' as const,
      attendees: 100,
      image_url: 'https://images.pexels.com/photos/3184306/pexels-photo-3184306.jpeg?auto=compress&cs=tinysrgb&w=400'
    }
  ];

  const pastActivities = [
    {
      id: '4',
      title: 'Network Security Bootcamp',
      description: 'Intensive 3-day bootcamp covering network security fundamentals and advanced topics.',
      date: '2024-11-15',
      type: 'workshop' as const,
      attendees: 45,
      highlights: ['Hands-on firewall configuration', 'Network monitoring tools', 'Incident response simulation']
    },
    {
      id: '5',
      title: 'Halloween Phishing Simulation',
      description: 'Educational phishing awareness campaign and simulation exercise.',
      date: '2024-10-31',
      type: 'social' as const,
      attendees: 200,
      highlights: ['Campus-wide awareness', '80% participation rate', 'Improved security awareness']
    },
    {
      id: '6',
      title: 'Guest Lecture: AI in Cybersecurity',
      description: 'Dr. Sarah Mitchell from MIT discussed the role of AI in modern cybersecurity.',
      date: '2024-09-20',
      type: 'seminar' as const,
      attendees: 150,
      highlights: ['Machine learning for threat detection', 'AI-powered security tools', 'Future trends discussion']
    }
  ];

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'workshop': return <BookOpen className="h-5 w-5" />;
      case 'competition': return <Trophy className="h-5 w-5" />;
      case 'seminar': return <Users className="h-5 w-5" />;
      case 'social': return <Coffee className="h-5 w-5" />;
      default: return <Calendar className="h-5 w-5" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'workshop': return 'text-blue-400 bg-blue-400/10';
      case 'competition': return 'text-yellow-400 bg-yellow-400/10';
      case 'seminar': return 'text-green-400 bg-green-400/10';
      case 'social': return 'text-purple-400 bg-purple-400/10';
      default: return 'text-gray-400 bg-gray-400/10';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="min-h-screen bg-slate-900 py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Upcoming Activities */}
        <div className="mb-20">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-white mb-4">Upcoming Activities</h1>
            <p className="text-xl text-gray-300">Join us for exciting cybersecurity events and learning opportunities</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {upcomingActivities.map((activity) => (
              <div key={activity.id} className="bg-slate-800 rounded-xl border border-slate-700 overflow-hidden hover:border-cyan-400 transition-colors">
                <div className="aspect-w-16 aspect-h-9">
                  <img
                    src={activity.image_url}
                    alt={activity.title}
                    className="w-full h-48 object-cover"
                  />
                </div>
                
                <div className="p-6">
                  <div className="flex items-center justify-between mb-3">
                    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${getTypeColor(activity.type)}`}>
                      {getTypeIcon(activity.type)}
                      {activity.type.charAt(0).toUpperCase() + activity.type.slice(1)}
                    </span>
                    <span className="text-xs text-gray-400 flex items-center gap-1">
                      <Users className="h-4 w-4" />
                      {activity.attendees} expected
                    </span>
                  </div>
                  
                  <h3 className="text-xl font-bold text-white mb-2">{activity.title}</h3>
                  <p className="text-gray-300 text-sm mb-4">{activity.description}</p>
                  
                  <div className="space-y-2 text-sm text-gray-400">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4" />
                      {formatDate(activity.date)}
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4" />
                      {activity.time}
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4" />
                      {activity.location}
                    </div>
                  </div>
                  
                  <button className="w-full mt-4 px-4 py-2 bg-cyan-500 text-white font-semibold rounded-lg hover:bg-cyan-600 transition-colors">
                    Register Interest
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Past Activities */}
        <div>
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-white mb-4">Past Activities</h2>
            <p className="text-lg text-gray-300">Celebrating our successful events and achievements</p>
          </div>

          <div className="space-y-6">
            {pastActivities.map((activity) => (
              <div key={activity.id} className="bg-slate-800 p-8 rounded-xl border border-slate-700">
                <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-6">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-3">
                      <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${getTypeColor(activity.type)}`}>
                        {getTypeIcon(activity.type)}
                        {activity.type.charAt(0).toUpperCase() + activity.type.slice(1)}
                      </span>
                      <span className="text-sm text-gray-400">
                        {formatDate(activity.date)}
                      </span>
                      <span className="text-xs text-gray-400 flex items-center gap-1">
                        <Users className="h-4 w-4" />
                        {activity.attendees} attended
                      </span>
                    </div>
                    
                    <h3 className="text-2xl font-bold text-white mb-2">{activity.title}</h3>
                    <p className="text-gray-300 mb-4">{activity.description}</p>
                    
                    {activity.highlights && (
                      <div>
                        <h4 className="text-sm font-semibold text-cyan-400 mb-2">Highlights:</h4>
                        <ul className="text-sm text-gray-300 space-y-1">
                          {activity.highlights.map((highlight, index) => (
                            <li key={index}>• {highlight}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Activities;