import React from 'react';
import { Shield, Target, Eye, Heart } from 'lucide-react';

const About: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-900 py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-white mb-4">About UGCC</h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            The University of Guyana's Cybersecurity Club is dedicated to creating a community 
            of cybersecurity enthusiasts and future professionals.
          </p>
        </div>

        {/* Mission, Vision, Values */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
          <div className="bg-slate-800 p-8 rounded-xl border border-slate-700">
            <Target className="h-12 w-12 text-cyan-400 mb-4" />
            <h3 className="text-2xl font-bold text-white mb-4">Our Mission</h3>
            <p className="text-gray-300">
              To educate, inspire, and prepare students for successful careers in cybersecurity 
              through practical learning, networking, and professional development.
            </p>
          </div>

          <div className="bg-slate-800 p-8 rounded-xl border border-slate-700">
            <Eye className="h-12 w-12 text-cyan-400 mb-4" />
            <h3 className="text-2xl font-bold text-white mb-4">Our Vision</h3>
            <p className="text-gray-300">
              To be the leading cybersecurity organization at the University of Guyana, 
              fostering innovation and excellence in digital security education.
            </p>
          </div>

          <div className="bg-slate-800 p-8 rounded-xl border border-slate-700">
            <Heart className="h-12 w-12 text-cyan-400 mb-4" />
            <h3 className="text-2xl font-bold text-white mb-4">Our Values</h3>
            <ul className="text-gray-300 space-y-2">
              <li>• Excellence in education</li>
              <li>• Ethical hacking practices</li>
              <li>• Community collaboration</li>
              <li>• Continuous learning</li>
              <li>• Professional integrity</li>
            </ul>
          </div>
        </div>

        {/* Constitution */}
        <div className="bg-slate-800 p-8 rounded-xl border border-slate-700 mb-16">
          <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-3">
            <Shield className="h-8 w-8 text-cyan-400" />
            Club Constitution
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h4 className="text-lg font-semibold text-cyan-400 mb-3">Article I - Purpose</h4>
              <p className="text-gray-300 mb-4">
                The UGCC exists to provide students with opportunities to learn about cybersecurity, 
                develop practical skills, and build professional networks in the field.
              </p>
              
              <h4 className="text-lg font-semibold text-cyan-400 mb-3">Article II - Membership</h4>
              <p className="text-gray-300">
                Membership is open to all University of Guyana students regardless of their 
                academic program, with a shared interest in cybersecurity.
              </p>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold text-cyan-400 mb-3">Article III - Activities</h4>
              <p className="text-gray-300 mb-4">
                Regular workshops, capture-the-flag competitions, guest lectures, 
                and collaborative projects with industry professionals.
              </p>
              
              <h4 className="text-lg font-semibold text-cyan-400 mb-3">Article IV - Ethics</h4>
              <p className="text-gray-300">
                All members must adhere to ethical hacking principles and use their 
                knowledge responsibly for defensive and educational purposes only.
              </p>
            </div>
          </div>
        </div>

        {/* Contact Information */}
        <div className="bg-slate-800 p-8 rounded-xl border border-slate-700">
          <h3 className="text-2xl font-bold text-white mb-6">Contact Us</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h4 className="text-lg font-semibold text-cyan-400 mb-3">General Information</h4>
              <p className="text-gray-300 mb-2">Email: ugcc@uog.edu.gy</p>
              <p className="text-gray-300 mb-2">Phone: +592-222-4000 ext. 3456</p>
              <p className="text-gray-300">Location: Computer Science Department, UG Campus</p>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold text-cyan-400 mb-3">Social Media</h4>
              <p className="text-gray-300 mb-2">Facebook: @UGCybersecurityClub</p>
              <p className="text-gray-300 mb-2">Instagram: @ugcc_official</p>
              <p className="text-gray-300">Discord: UGCC Community Server</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;