import React from 'react';
import { Shield, Users, Calendar, Award, ArrowRight } from 'lucide-react';

interface HomeProps {
  setActiveSection: (section: string) => void;
}

const Home: React.FC<HomeProps> = ({ setActiveSection }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Hero Section */}
      <section className="pt-16 pb-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <Shield className="h-20 w-20 text-cyan-400 mx-auto mb-6" />
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
              University of Guyana
              <span className="block text-cyan-400">Cybersecurity Club</span>
            </h1>
            <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">
              Empowering the next generation of cybersecurity professionals through education, 
              practical experience, and community engagement.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => setActiveSection('register')}
                className="px-8 py-3 bg-cyan-500 text-white font-semibold rounded-lg hover:bg-cyan-600 transition-colors flex items-center justify-center gap-2"
              >
                Join Our Community <ArrowRight className="h-5 w-5" />
              </button>
              <button
                onClick={() => setActiveSection('about')}
                className="px-8 py-3 border-2 border-cyan-400 text-cyan-400 font-semibold rounded-lg hover:bg-cyan-400 hover:text-slate-900 transition-colors"
              >
                Learn More
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-slate-800/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-white mb-4">Why Join UGCC?</h2>
            <p className="text-gray-300 text-lg max-w-2xl mx-auto">
              Discover opportunities to grow, learn, and connect with like-minded cybersecurity enthusiasts
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-slate-700/50 p-6 rounded-xl border border-slate-600 hover:border-cyan-400 transition-colors">
              <Users className="h-12 w-12 text-cyan-400 mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">Community</h3>
              <p className="text-gray-300">Connect with fellow students passionate about cybersecurity</p>
            </div>

            <div className="bg-slate-700/50 p-6 rounded-xl border border-slate-600 hover:border-cyan-400 transition-colors">
              <Calendar className="h-12 w-12 text-cyan-400 mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">Events</h3>
              <p className="text-gray-300">Regular workshops, competitions, and guest speaker sessions</p>
            </div>

            <div className="bg-slate-700/50 p-6 rounded-xl border border-slate-600 hover:border-cyan-400 transition-colors">
              <Award className="h-12 w-12 text-cyan-400 mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">Skills</h3>
              <p className="text-gray-300">Develop practical cybersecurity skills through hands-on experience</p>
            </div>

            <div className="bg-slate-700/50 p-6 rounded-xl border border-slate-600 hover:border-cyan-400 transition-colors">
              <Shield className="h-12 w-12 text-cyan-400 mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">Career</h3>
              <p className="text-gray-300">Build your professional network and career opportunities</p>
            </div>
          </div>
        </div>
      </section>

      {/* Club Motto */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <blockquote className="text-2xl md:text-3xl font-medium text-cyan-400 mb-6">
            "Securing Tomorrow, Today"
          </blockquote>
          <p className="text-gray-300 text-lg">
            Our mission is to foster a culture of cybersecurity awareness and excellence, 
            preparing students for the challenges of the digital age.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Home;