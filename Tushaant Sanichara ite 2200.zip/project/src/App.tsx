import React, { useState, useEffect } from 'react';
import { AuthProvider } from './contexts/AuthContext';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './components/sections/Home';
import About from './components/sections/About';
import Executives from './components/sections/Executives';
import Activities from './components/sections/Activities';
import Register from './components/sections/Register';
import Login from './components/sections/Login';
import Dashboard from './components/sections/Dashboard';

function App() {
  const [activeSection, setActiveSection] = useState('home');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Close mobile menu when section changes
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [activeSection]);

  const renderSection = () => {
    switch (activeSection) {
      case 'home':
        return <Home setActiveSection={setActiveSection} />;
      case 'about':
        return <About />;
      case 'executives':
        return <Executives />;
      case 'activities':
        return <Activities />;
      case 'register':
        return <Register />;
      case 'login':
        return <Login setActiveSection={setActiveSection} />;
      case 'dashboard':
        return <Dashboard />;
      default:
        return <Home setActiveSection={setActiveSection} />;
    }
  };

  return (
    <AuthProvider>
      <div className="min-h-screen flex flex-col bg-slate-900">
        <Header
          activeSection={activeSection}
          setActiveSection={setActiveSection}
          mobileMenuOpen={mobileMenuOpen}
          setMobileMenuOpen={setMobileMenuOpen}
        />
        
        <main className="flex-1">
          {renderSection()}
        </main>
        
        <Footer />
      </div>
    </AuthProvider>
  );
}

export default App;