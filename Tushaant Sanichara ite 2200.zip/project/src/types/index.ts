export interface Member {
  id: string;
  email: string;
  full_name: string;
  student_id: string;
  year_of_study: number;
  program: string;
  phone: string;
  interests: string;
  created_at: string;
}

export interface MemberProfile {
  id: string;
  member_id: string;
  bio: string;
  skills: string[];
  github_url?: string;
  linkedin_url?: string;
  portfolio_url?: string;
  updated_at: string;
}

export interface Executive {
  id: string;
  name: string;
  position: string;
  year: string;
  image_url?: string;
  bio: string;
  is_current: boolean;
}

export interface Activity {
  id: string;
  title: string;
  description: string;
  date: string;
  type: 'workshop' | 'competition' | 'seminar' | 'social';
  is_past: boolean;
  image_url?: string;
}

export interface ProspectiveMember {
  id: string;
  full_name: string;
  email: string;
  student_id: string;
  year_of_study: number;
  program: string;
  phone: string;
  interests: string;
  created_at: string;
}